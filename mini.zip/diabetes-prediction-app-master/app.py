import streamlit as st
#import pandas as pd
from PIL import Image
import pickle 
from pathlib import Path

# --- PATH SETTINGS ---
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()
css_file = '/home/akash/Downloads/diabetes-prediction-app-master/styles/style.css'
css_file1 = '/home/akash/Downloads/diabetes-prediction-app-master/styles/touch.css'

    
st.title('Diabetes Prediction App')
st.write('The data for the following example is originally from the National Institute of Diabetes and Digestive and Kidney Diseases and contains information on females at least 21 years old of Pima Indian heritage. This is a sample application and cannot be used as a substitute for real medical advice.')
image = Image.open('data/diabetes_image.jpg')
st.image(image, use_column_width=True)
st.write('Please fill in the details of the person under consideration in the left sidebar and click on the button below!')

name = st.text_input("Name:")
age =           st.sidebar.number_input("Age in Years", 1, 150, 25, 1)
pregnancies =   st.sidebar.number_input("Number of Pregnancies", 0, 20, 0, 1)
glucose =       st.sidebar.slider("Glucose Level", 0, 200, 25, 1)
skinthickness = st.sidebar.slider("Skin Thickness", 0, 99, 20, 1)
bloodpressure = st.sidebar.slider('Blood Pressure', 0, 122, 69, 1)
insulin =       st.sidebar.slider("Insulin", 0, 846, 79, 1)
bmi =           st.sidebar.slider("BMI", 0.0, 67.1, 31.4, 0.1)
dpf =           st.sidebar.slider("Diabetics Pedigree Function", 0.000, 2.420, 0.471, 0.001)
submit = st.button('Predict')


row = [pregnancies, glucose, bloodpressure, skinthickness, insulin, bmi, dpf, age]
pickle_in = open('/home/akash/Downloads/diabetes-prediction-app-master/models/model', 'rb')
classifier = pickle.load(pickle_in)

if submit:
    prediction = classifier.predict([[pregnancies, glucose, bloodpressure, skinthickness, insulin, bmi, dpf, age]])
    if prediction == 0:
        st.write('Congratulation',name,'You are not diabetic')
    else:
        st.write(name," we are really sorry to say but it seems like you are Diabetic.")





st.header(":mailbox: Get In Touch With Me!")


contact_form = '''
<form action="https://formsubmit.co/akashkathole74@gmail.com" method="POST">
     <input type="hidden" name="_captcha" value="false">
     <input type="text" name="name" placeholder="Your name" required>
     <input type="email" name="email" placeholder="Your email" required>
     <textarea name="message" placeholder="Your message here"></textarea>
     <button type="submit">Send</button>
</form>
'''


st.markdown(contact_form, unsafe_allow_html=True)

# Use Local CSS File
css_file1 = '/home/akash/Downloads/diabetes-prediction-app-master/styles/touch.css'
def local_css(css_file1):
    with open(css_file1) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)